#include <at89c5131.h>
#include "lcd.h"		//Header file with LCD interfacing functions
#include "serial.c"	//C file with UART interfacing functions
#include "words.c"  //File with an array of words

//Main function
void main(void)
{
		unsigned char ch, flag, flag2, lives, i, *s, wordnum = 0;
		
		//Call initialization functions
		lcd_init();
		uart_init();
		
	while(1)
		{
			unsigned char on[] = {0,0,0,0,0,0};
			lives = 0x2F;
			
			//These strings will be printed in terminal software
			transmit_string("\n\r********HANGMAN!********\n");
			transmit_string("\r*****Word Number: ");
			transmit_num(wordnum+1);
			transmit_string("******\n\n\r*");
			lcd_cmd(0x01);
			ch = '1';
			while(1)
			{
					//Receive a character
					flag = 1;
					flag2 = 1;
					s = b[wordnum];
					i = 0; 
					//Decide which test function to run based on character sent
					//Displays the string on the terminal software
					lcd_cmd(0x80);
					if(96<ch) ch= ch - 32;
					while(*s!='\0')
					{
						if(ch == *s)
						{
							on[i]=1;
							flag = 0;
						}
						if(on[i++])
						{
							lcd_write_char(*s++);
						}
						else
						{
							flag2 = 0;
							lcd_write_char('-');
							s++;
						}
					}
					lives = lives + flag;
					if(flag)
					{
						if (lives>48) transmit_string("\n\r*Sorry, wrong!*\n\r*");
					}
					else transmit_string("\n\r*Correct letter!*\n\r*");
					transmit_char(102-lives);
					transmit_string(" lives remaining*\n\r");
					lcd_cmd(0xC0);
					if(flag2)
					{
						lcd_write_string("Yay! Correct    ");
						wordnum++;
						transmit_string("\n\r*Word Guessed!*\n\r*Press any key to start*\n\r");
						ch = receive_char();
						break;
					}
					lcd_write_string("Wrong:");
					lcd_write_char(lives);
					lcd_write_string(" Word:");
					lcd_num(wordnum+1);
					if(lives==0x36)
					{
						lcd_cmd(0x01);
						lcd_cmd(0x80);
						lcd_write_string(b[wordnum]);
						lcd_cmd(0xC0);
						lcd_write_string("Game Over :(");
						
						wordnum++;
						transmit_string("\n\r*Press any key to start*\n\r");
						ch = receive_char();
						break;
					}
					msdelay(100);
					ch = receive_char();
			}
		}
}
